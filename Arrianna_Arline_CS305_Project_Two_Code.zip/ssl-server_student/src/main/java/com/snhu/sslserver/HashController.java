package com.snhu.sslserver;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HashController {

    @GetMapping("/hash")
    public String getHash() throws Exception {

        String data = "Arrianna-Artemis-Financial-Unique-String-2026";

        String hash = HashService.generateHash(data);

        return "<h2>Your Name: Arrianna</h2>"
                + "<p>Data String: " + data + "</p>"
                + "<p>SHA-256 Hash: " + hash + "</p>";
    }
}
